<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        session_start();
        
        if(isset($_SESSION['nombre_no_insertado'])) {
            echo '<p>'.$_SESSION['nombre_no_insertado'].'</p>';
        }
    ?>
    
    <form action="Insertar.php" method="post">
        <p>Tipo<input type="text" name="Tipo" required></p>
        <p>Color <input type="text" name="Color" required></p>
        <p>Talla <input type="text" name="Talla" required></p>
        <p>Preu <input type="text" name="Preu" required></p>
        <p>Id <input type="text" name="Id" required></p>
        <input type="submit" name="Enviar">
        <input type="reset" name="Borrar">
    </form>
</body>
</html>