<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Document</title>
</head>
<body>
    <?php
        include_once('db.php');
        $conectar = conexion();
        session_start();

        $_SESSION['nombre_insertado'] = 'El nombre se ha insertado';
        header('Location: Mostrar.php');

        $consulta = 'SELECT * FROM Ropa';
        //La función mysqli_query lanza una consulta a la base de datos para conectarse
        $result = mysqli_query($conectar, $consulta);
        //Recoje la longitud de la fila de la tabla
        $filas = mysqli_num_rows($result);
        
        if($filas == 0) {
            echo 'No hay ningún registro';
        }

    ?>
    <button><a href="Formulario.php">Añadir producto</a></button>

    <table>
        <tr>
            <th>Tipo</th>
            <th>Color</th>
            <th>Talla</th>
            <th>Preu</th>
            <th>Id</td>
        </tr>

        <?php
            //La función mysqli_fetch_assoc muestra por pantalla los datos de la tabla
            while ($fila = mysqli_fetch_assoc($result)) {
                echo '<tr>';
                
                echo '<td>'.$fila['Tipo'].'</td>';
                echo '<td>'.$fila['Color'].'</td>';
                echo '<td>'.$fila['Talla'].'</td>';
                echo '<td>'.$fila['Preu'].'</td>';
                echo '<td>'.$fila['Id'].'</td>';
                
                echo '</tr>';
            }
        ?>
    </table>
</body>
</html>